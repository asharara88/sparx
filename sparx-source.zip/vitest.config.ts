import { defineConfig } from 'vitest/config';
export default defineConfig({
  test: { include: ['tests/**/*.test.ts'], exclude: ['tests/live/**', 'node_modules/**'], environment: 'node', globals: false },
});
