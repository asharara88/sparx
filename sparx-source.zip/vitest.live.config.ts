import { defineConfig } from 'vitest/config';
// Separate config so the live suite isn't blocked by the default exclude.
export default defineConfig({
  test: { include: ['tests/live/**/*.test.ts'], environment: 'node', globals: false, testTimeout: 60000 },
});
