# AI YouTube Studio

Semi-autonomous multi-agent pipeline that takes a weekly YouTube episode from idea → published long-form video + derived Shorts, with three human approval gates (concept, script, final cut).

This is the **foundation build**: the orchestrator, the shared Episode State, a Supabase-backed store, 13 agent stubs, the shared-skill layer, and browser control (Playwright + Claude-in-Chrome). Agents return mock data so the whole pipeline runs end-to-end before any paid APIs are wired in.

See `../YouTube-Studio-Build-Spec.md` for architecture, and `RUNBOOK.md` for how to produce a real episode step by step.

## Architecture in one paragraph

A **Producer** runs a state machine over a single shared **Episode State** JSON document (`src/types/episode.ts`). Each state invokes one or more **agents** (`src/agents/`) that read fields from the state and write new ones back; agents never talk to each other directly. Money-spending steps check a budget ledger first. The pipeline pauses at three **gates** for human approval. Reusable logic lives in **skills** (`src/skills/`), and browser actions go through `src/browser/`.

```
draft → researching → [GATE A] → scripting → [GATE B]
      → generating → assembling → qa → [GATE C]
      → distributing → published
```

## Quick start

```bash
npm install
npx playwright install chromium     # for the browser path
# ffmpeg is bundled via ffmpeg-static — no system install needed
cp .env.example .env                # fill in Supabase + keys when ready

npm run typecheck                   # type-check the whole project
npm test                            # unit tests (vitest)
npm run demo                        # run the pipeline skeleton (auto-approves gates)
npm run browser:test -- https://example.com   # smoke-test Playwright
npx tsx scripts/inspect.ts           # print the concept/script/shot prompts
npm run preflight                    # which integrations are live vs mock
npm run episode -- "your topic"      # produce one episode end to end
npm run review list                  # episodes awaiting human approval (needs Supabase)
npm run schedule                     # weekly automated episode kickoff (cron)
npm run cost <episodeId>             # per-episode cost breakdown
npm run report [episodeId]           # full run report (timeline + cost + outputs)
```

The skeleton runs with **no credentials** — it falls back to an in-memory store and mock agents. Add Supabase env vars to persist the Episode State to the `sparx studio` project.

## Layout

| Path | What |
|------|------|
| `src/types/episode.ts` | The Episode State schema (the one shared object) |
| `src/producer/` | Orchestrator, state machine, budget, envelope |
| `src/agents/` | 13 agents (Producer + 12 specialists), currently stubs |
| `src/skills/` | Reusable skills: video-prompt ✅, cost ✅, research/web-search ✅ (Tavily+mock), research/seo ✅; others stubbed |
| `src/llm/` | Robust LLM client (retries, timeout, usage/cost, schema-validated JSON) |
| `src/config.ts` | Typed, validated env config (zod) |
| `src/logger.ts` | Structured logger (pretty/json) |
| `src/errors.ts` | Typed pipeline/agent errors |
| `src/schemas/` | Zod schemas validating all LLM I/O |
| `src/media/` | Media providers (voice, video, stock, music) — real + mock |
| `tests/` | Vitest unit tests |
| `src/state/` | Supabase client + state store (Supabase or in-memory) |
| `src/browser/` | Playwright (automated) + Claude-in-Chrome (supervised) |
| `supabase/migrations/` | `0001_init_episode_state.sql` |

## Environment

| Var | Purpose |
|-----|---------|
| `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY` | Persist Episode State |
| `AUTO_APPROVE_GATES` | `true` lets the skeleton run unattended (dev) |
| `BUDGET_CAP_USD` | Monthly spend cap (default 500) |
| `PLAYWRIGHT_MODE` | `headless` or `headed` |
| `CHROME_CDP_ENDPOINT` | Attach Playwright to a running Chrome (optional) |
| `ANTHROPIC_API_KEY` | Real LLM calls for Phase 1 agents (mock fallback otherwise) |
| `LLM_MODEL` / `LLM_FAST_MODEL` | Model tiers (default sonnet / haiku) |
| `LLM_MAX_RETRIES` / `LLM_TIMEOUT_MS` | LLM resilience |
| `TAVILY_API_KEY` | Live web research (mock fallback otherwise) |
| `LOG_LEVEL` / `LOG_FORMAT` | `debug..error` / `pretty`\|`json` |

## Build phases

1. **Foundation (this repo)** — orchestrator, state, gates, stubs, browser. ✅
2. **Pre-production** — real Research, Scriptwriter, Visual Director + video-prompt skill. ✅ (LLM-backed; runs on mocks without a key)
3. **Generation** — Voiceover, Video Gen, Asset Sourcing, Music + the Cost skill.
4. **Assembly + QA**, then **Distribution**.

## Status

**v0.3 — all 12 agents real (Phase 1 deepest).** Research, Scriptwriter, and Visual Director are multi-step, reasoned, and schema-validated:
- **Research**: live web context → ideate candidate angles → score & package a full concept (working title, audience, thumbnail concept, scored alternatives, keyword clusters).
- **Scriptwriter**: hook variants + beat sheet → full draft with per-section retention devices → self-critique pass (can upgrade the hook).
- **Visual Director**: reasoned per-shot source choice → model-specific prompts (video-prompt skill v2: aspect ratio, negatives, continuity seed) → cost-aware budget optimization.

Phases 2–4 are implemented to the same standard via a media-provider layer (real path + mock fallback): **Voiceover** (ElevenLabs), **Video Generation** (real Runway API — text-to-video task submit + poll to completion; budget-aware, self-QC + stock fallback), **Asset Sourcing** (Pexels, backfills skipped shots), **Avatar** (real HeyGen API — v2 generate + status poll, for intros/cutaways/dubs), **Music**; **Editor** builds a real EDL/timeline.json, **renders an actual MP4 via ffmpeg** (per-segment normalize → concat → music mix) + an SRT caption track; **QA** does coverage + license verification, AI-disclosure logic, and an LLM claim/brand review; **Shorts** (LLM segment selection), **Packaging** (LLM CTR titles/desc + real thumbnail images via Runway gen4_image), **Publishing** (real YouTube Data API v3 resumable upload, private-by-default; real tags/timestamped chapters/AI-disclosure).

Production hardening: typed config, structured logging, typed errors, an LLM client with retries/backoff/timeout + usage/cost accounting + JSON schema-validation-with-repair, and a vitest suite (45 tests). Runs fully offline on deterministic mocks; set `ANTHROPIC_API_KEY` (and optionally `TAVILY_API_KEY`) for real output.

All 12 specialist agents are implemented. Real external APIs are wired where simple (ElevenLabs, Pexels, Tavily, Anthropic); Runway video is fully wired (async task submit + poll); YouTube upload is wired via the real resumable Data API (activates with an OAuth token + a real rendered file); all external paths now have real implementations with mock fallback so nothing returns fake "real" output.
