# Live API tests

Real network calls to verify your credentials work. Each test **skips** unless its
key is present, so this suite is safe to run anytime:

```bash
npm run test:live
```

These do the cheapest possible call per provider (auth/connectivity checks, no paid
generation). Runway video / HeyGen video generation are intentionally NOT exercised
here (they cost money and minutes) — they're covered by stubbed unit tests.
