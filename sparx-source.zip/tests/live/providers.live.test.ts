import 'dotenv/config';
import { describe, it, expect } from 'vitest';
import { z } from 'zod';
import { __setLLM, getLLM } from '../../src/llm/client.js';
import { __setStock, getStock } from '../../src/media/stock.js';
import { __setWebSearch, webResearch } from '../../src/skills/research/webSearch.js';

const env = process.env;

describe('live API credentials', () => {
  it.skipIf(!env.ANTHROPIC_API_KEY)('Anthropic LLM returns valid JSON', async () => {
    __setLLM(null);
    const llm = getLLM();
    expect(llm.live).toBe(true);
    const r = await llm.complete({ tier: 'fast', system: 'Reply with JSON.', prompt: 'Return {"ok":true}.', schema: z.object({ ok: z.boolean() }), mock: '{"ok":true}' });
    expect(r.data?.ok).toBe(true);
    expect(r.usage.inputTokens).toBeGreaterThan(0);
  });

  it.skipIf(!env.TAVILY_API_KEY)('Tavily web search returns results', async () => {
    __setWebSearch(null);
    const r = await webResearch('youtube growth tips', 3);
    expect(r.live).toBe(true);
    expect(r.results.length).toBeGreaterThan(0);
    expect(r.results[0]!.url).toMatch(/^https?:\/\//);
  });

  it.skipIf(!env.PEXELS_API_KEY)('Pexels returns a licensed asset', async () => {
    __setStock(null);
    const a = await getStock().find('ocean sunset', 'image');
    expect(a?.uri).toMatch(/^https?:\/\//);
    expect(a?.license).toBeTruthy();
  });

  it.skipIf(!env.HEYGEN_API_KEY)('HeyGen credentials authenticate (GET /v2/avatars)', async () => {
    const res = await fetch('https://api.heygen.com/v2/avatars', { headers: { 'X-Api-Key': env.HEYGEN_API_KEY! } });
    expect(res.ok).toBe(true);
  });

  it.skipIf(!env.YOUTUBE_ACCESS_TOKEN)('YouTube token authenticates (channels.list mine)', async () => {
    const res = await fetch('https://www.googleapis.com/youtube/v3/channels?part=id&mine=true', { headers: { Authorization: `Bearer ${env.YOUTUBE_ACCESS_TOKEN}` } });
    expect(res.ok).toBe(true);
  });
});
