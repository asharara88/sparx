import { describe, it, expect, beforeEach } from 'vitest';
import { Producer } from '../src/producer/producer.js';
import { newEpisodeState } from '../src/types/episode.js';
import { createStore } from '../src/state/store.js';
import { buildEpisodeReport, formatEpisodeReport } from '../src/reporting/episodeReport.js';
import { __setLLM } from '../src/llm/client.js';

beforeEach(() => __setLLM(null));

describe('episode reporting', () => {
  it('assembles a report from a completed run (events + cost + status)', async () => {
    const store = createStore();
    const final = await new Producer({ autoApproveGates: true, store }).run(newEpisodeState('rep1', { niche: 'test' }));
    expect(final.status).toBe('published');
    const r = await buildEpisodeReport(store, 'rep1');
    expect(r.found).toBe(true);
    expect(r.events.length).toBeGreaterThan(0);
    expect(r.cost?.over_budget).toBe(false);
    const text = formatEpisodeReport(r);
    expect(text).toContain('Episode rep1');
    expect(text).toContain('timeline');
  });
  it('reports not-found for unknown episodes', async () => {
    const r = await buildEpisodeReport(createStore(), 'nope');
    expect(r.found).toBe(false);
    expect(formatEpisodeReport(r)).toBe('Episode not found.');
  });
});
