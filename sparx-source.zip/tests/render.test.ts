import { describe, it, expect } from 'vitest';
import { execFileSync } from 'node:child_process';
import { mkdtempSync, existsSync, statSync } from 'node:fs';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import ffmpegPath from 'ffmpeg-static';
import { segmentArgs, buildSrt, isRealAsset, renderEpisode } from '../src/media/render.js';

const FF = ffmpegPath as unknown as string;

describe('render — pure helpers', () => {
  it('segmentArgs loops images and sets duration + libx264', () => {
    const a = segmentArgs({ visual: 'x.png', durationS: 4, width: 1920, height: 1080, isImage: true, out: 'o.mp4' });
    expect(a).toContain('-loop'); expect(a).toContain('libx264');
    expect(a.join(' ')).toContain('-t 4');
  });
  it('segmentArgs uses silent audio when no audio given', () => {
    const a = segmentArgs({ visual: 'v.mp4', durationS: 3, width: 1280, height: 720, isImage: false, out: 'o.mp4' });
    expect(a.join(' ')).toContain('anullsrc');
    expect(a).not.toContain('-loop');
  });
  it('isRealAsset distinguishes real vs mock', () => {
    expect(isRealAsset('https://x/y.mp4')).toBe(true);
    expect(isRealAsset('/tmp/a.mp4')).toBe(true);
    expect(isRealAsset('mock://video/x.mp4')).toBe(false);
    expect(isRealAsset(undefined)).toBe(false);
  });
  it('buildSrt formats timecodes cumulatively', () => {
    const srt = buildSrt([{ visual: 'a', durationS: 2, caption: 'one' }, { visual: 'b', durationS: 3, caption: 'two' }]);
    expect(srt).toContain('00:00:00,000 --> 00:00:02,000');
    expect(srt).toContain('00:00:02,000 --> 00:00:05,000');
    expect(srt).toContain('two');
  });
});

describe('render — real ffmpeg end-to-end', () => {
  it('renders an MP4 from real local image + audio', async () => {
    const work = mkdtempSync(join(tmpdir(), 'rendertest_'));
    const img = join(work, 'img.png');
    const wav = join(work, 'vo.wav');
    // make a real image and a real audio clip with ffmpeg
    execFileSync(FF, ['-y', '-f', 'lavfi', '-i', 'color=c=blue:s=320x240', '-frames:v', '1', img]);
    execFileSync(FF, ['-y', '-f', 'lavfi', '-i', 'sine=frequency=440:duration=2', '-t', '2', wav]);

    const res = await renderEpisode({
      episodeId: 'test_ep',
      segments: [
        { visual: img, audio: wav, durationS: 1, caption: 'hello' },
        { visual: img, durationS: 1, caption: 'world' },
      ],
      outDir: join(work, 'out'),
      width: 320, height: 240,
    });

    expect(res.rendered).toBe(true);
    expect(existsSync(res.path)).toBe(true);
    expect(statSync(res.path).size).toBeGreaterThan(0);
    expect(res.srtPath && existsSync(res.srtPath)).toBe(true);
  }, 60000);
});
