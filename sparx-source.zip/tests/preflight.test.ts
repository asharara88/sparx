import { describe, it, expect } from 'vitest';
import { preflightReport, formatPreflight, hasBlockingProblems } from '../src/preflight.js';

describe('preflight', () => {
  it('all integrations mock with empty env (ffmpeg live)', () => {
    const r = preflightReport({} as NodeJS.ProcessEnv);
    const byName = Object.fromEntries(r.map((c) => [c.name, c]));
    expect(byName['LLM (Anthropic)']!.mode).toBe('mock');
    expect(byName['Render (ffmpeg)']!.mode).toBe('live');
    expect(hasBlockingProblems(r)).toBe(false);
  });
  it('keys flip integrations to live', () => {
    const r = preflightReport({ ANTHROPIC_API_KEY: 'x', RUNWAY_API_KEY: 'y' } as any);
    const byName = Object.fromEntries(r.map((c) => [c.name, c]));
    expect(byName['LLM (Anthropic)']!.mode).toBe('live');
    expect(byName['Video + thumbnails (Runway)']!.mode).toBe('live');
  });
  it('flags HeyGen key without avatar/voice ids as a problem', () => {
    const r = preflightReport({ HEYGEN_API_KEY: 'k' } as any);
    const hg = r.find((c) => c.name.startsWith('Avatar'))!;
    expect(hg.mode).toBe('live');
    expect(hg.ok).toBe(false);
    expect(hasBlockingProblems(r)).toBe(true);
  });
  it('formats a readable report', () => {
    expect(formatPreflight(preflightReport({} as any))).toContain('Preflight —');
  });
});
