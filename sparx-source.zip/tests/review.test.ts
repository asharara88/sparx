import { describe, it, expect, beforeEach } from 'vitest';
import { Producer } from '../src/producer/producer.js';
import { buildReviewPayload } from '../src/producer/review.js';
import { newEpisodeState } from '../src/types/episode.js';
import { createStore } from '../src/state/store.js';
import { __setLLM } from '../src/llm/client.js';

beforeEach(() => __setLLM(null));

describe('approval gates', () => {
  it('pauses at concept gate with a review payload (no auto-approve)', async () => {
    const s = newEpisodeState('ep_g', { niche: 'test' });
    const f = await new Producer({ autoApproveGates: false }).run(s);
    expect(f.status).toBe('concept_review');
    expect(f.review?.gate).toBe('A');
    expect(f.review?.items.length).toBeGreaterThan(0);
  });

  it('approve advances through all three gates to published', async () => {
    const store = createStore();
    const p = new Producer({ autoApproveGates: false, store });
    let s = await p.run(newEpisodeState('ep_a', { niche: 'test' }));
    expect(s.status).toBe('concept_review');
    s = await p.decide(s, 'approve');
    expect(s.status).toBe('script_review');
    expect(s.review?.gate).toBe('B');
    s = await p.decide(s, 'approve');
    expect(s.status).toBe('cut_review');
    expect(s.review?.gate).toBe('C');
    s = await p.decide(s, 'approve');
    expect(s.status).toBe('published');
    expect(s.review).toBeNull();
  });

  it('reject sends the episode to failed', async () => {
    const p = new Producer({ autoApproveGates: false });
    let s = await p.run(newEpisodeState('ep_r', { niche: 'test' }));
    s = await p.decide(s, 'reject', 'not interesting');
    expect(s.status).toBe('failed');
  });

  it('revise rolls back to research, records notes, and re-pauses at the gate', async () => {
    const p = new Producer({ autoApproveGates: false });
    let s = await p.run(newEpisodeState('ep_v', { niche: 'test' }));
    expect(s.status).toBe('concept_review');
    s = await p.decide(s, 'revise', 'make it punchier');
    expect(s.revision_notes).toContain('make it punchier');
    expect(s.concept.approved).toBe(false);
    expect(s.status).toBe('concept_review'); // re-ran research, paused again
  });

  it('buildReviewPayload includes gate-specific items', () => {
    const s = newEpisodeState('ep_p', { niche: 'test' });
    s.concept.working_title = 'T'; s.concept.angle = 'A';
    const a = buildReviewPayload('A', s);
    expect(a.gate).toBe('A');
    expect(a.items.some((i) => i.label === 'Angle')).toBe(true);
  });
});
