import { describe, it, expect } from 'vitest';
import { languageDirective, languageName, isEnglish } from '../src/i18n.js';

describe('i18n', () => {
  it('returns empty directive for English (no behavior change)', () => {
    expect(languageDirective(['en'])).toBe('');
    expect(languageDirective(['en-US'])).toBe('');
    expect(isEnglish(['en'])).toBe(true);
  });
  it('builds an Arabic directive with dialect, keeping prompts English', () => {
    const d = languageDirective(['ar'], 'Egyptian Arabic');
    expect(d).toContain('Arabic');
    expect(d).toContain('Egyptian Arabic dialect');
    expect(d).toContain('generation prompts and shot descriptions in English');
    expect(isEnglish(['ar'])).toBe(false);
  });
  it('maps language codes to names', () => {
    expect(languageName('ar')).toBe('Arabic');
    expect(languageName('es')).toBe('Spanish');
  });
});
