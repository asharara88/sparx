import { describe, it, expect } from 'vitest';
import { newEpisodeState } from '../src/types/episode.js';
import { GUARDS } from '../src/producer/stateMachine.js';
import { buildCostReport } from '../src/cost/report.js';
import * as budget from '../src/producer/budget.js';

function genShot(cost: number) {
  return { shot_id: 'sh1', section_id: 's1', source: 'generated' as const, duration_s: 4, prompt: { runway: 'x' }, selected_asset: null, cost_estimate_usd: cost };
}

describe('budget guardrails', () => {
  it('blocks generating when projected cost exceeds remaining', () => {
    const s = newEpisodeState('b1', { cap_usd_month: 0.1 });
    s.script.approved = true;
    s.shot_list = [genShot(0.05)]; // + thumbnails (~0.16) projection > 0.10
    const v = GUARDS.generating!(s);
    expect(v).toMatch(/exceeds remaining budget/);
  });
  it('allows generating within budget', () => {
    const s = newEpisodeState('b2', { cap_usd_month: 500 });
    s.script.approved = true;
    s.shot_list = [genShot(0.05)];
    expect(GUARDS.generating!(s)).toBeNull();
  });
  it('cost report breaks spend down by agent', () => {
    const s = newEpisodeState('b3', { cap_usd_month: 10 });
    budget.record(s, 'video_generation', 2);
    budget.record(s, 'avatar', 1);
    budget.record(s, 'video_generation', 0.5);
    const r = buildCostReport(s);
    expect(r.total_usd).toBeCloseTo(3.5, 4);
    expect(r.by_agent[0]!.agent).toBe('video_generation');
    expect(r.by_agent[0]!.usd).toBeCloseTo(2.5, 4);
    expect(r.over_budget).toBe(false);
  });
});
