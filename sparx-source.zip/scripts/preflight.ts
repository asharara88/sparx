import 'dotenv/config';
import { preflightReport, formatPreflight } from '../src/preflight.js';
console.log(formatPreflight(preflightReport()));
