// Review CLI for the human approval gates. Requires a persistent store (Supabase)
// to see episodes paused in a separate run.
//   npm run review list
//   npm run review show <episodeId>
//   npm run review approve <episodeId>
//   npm run review revise  <episodeId> "your notes"
//   npm run review reject  <episodeId> ["reason"]
import 'dotenv/config';
import { createStore } from '../src/state/store.js';
import { Producer } from '../src/producer/producer.js';
import { renderReview } from '../src/producer/review.js';
import { getSupabase } from '../src/state/supabase.js';

const REVIEW_STATES = ['concept_review', 'script_review', 'cut_review'];

async function main() {
  const [cmd, episodeId, ...rest] = process.argv.slice(2);
  const notes = rest.join(' ').trim() || undefined;
  const store = createStore();
  const producer = new Producer({ autoApproveGates: false, store, log: (m) => console.log('  ' + m) });

  if (!getSupabase() && cmd !== 'help') {
    console.log('NOTE: no Supabase configured — using in-memory store, which does not persist across processes.');
    console.log('Set SUPABASE_URL + SUPABASE_SERVICE_ROLE_KEY to use the review CLI across runs.\n');
  }

  switch (cmd) {
    case 'list': {
      const rows = await store.listByStatus(REVIEW_STATES);
      if (!rows.length) { console.log('No episodes awaiting review.'); break; }
      console.log('Episodes awaiting review:');
      for (const r of rows) console.log(`  ${r.episode_id}  [${r.status}]`);
      break;
    }
    case 'show': {
      const s = episodeId ? await store.load(episodeId) : null;
      if (!s) { console.log('Episode not found.'); break; }
      if (!s.review) { console.log(`Episode ${s.episode_id} is not awaiting review (status: ${s.status}).`); break; }
      console.log(renderReview(s.review));
      console.log('\nDecide: npm run review approve|revise|reject ' + s.episode_id);
      break;
    }
    case 'approve':
    case 'revise':
    case 'reject': {
      if (!episodeId) { console.log('Usage: npm run review ' + cmd + ' <episodeId> [notes]'); break; }
      const decision = cmd as 'approve' | 'revise' | 'reject';
      if (decision === 'revise' && !notes) { console.log('Revise requires notes: npm run review revise <id> "what to change"'); break; }
      const final = await producer.resumeById(episodeId, decision, notes);
      console.log(`\nDecision applied. New status: ${final.status}`);
      if (final.review) console.log(`Next review pending: GATE ${final.review.gate} — run: npm run review show ${episodeId}`);
      break;
    }
    default:
      console.log('Commands: list | show <id> | approve <id> | revise <id> "notes" | reject <id> ["reason"]');
  }
}
main().catch((e) => { console.error(String(e?.message ?? e)); process.exit(1); });
