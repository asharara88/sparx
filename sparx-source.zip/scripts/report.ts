// Per-episode run report. Usage:
//   npm run report               (recent episodes — needs Supabase)
//   npm run report <episodeId>   (full report)
import 'dotenv/config';
import { createStore } from '../src/state/store.js';
import { buildEpisodeReport, formatEpisodeReport } from '../src/reporting/episodeReport.js';
import { getSupabase } from '../src/state/supabase.js';

async function main() {
  const id = process.argv[2];
  const store = createStore();
  if (!id) {
    if (!getSupabase()) { console.log('Recent-episode listing needs Supabase (in-memory store is per-process).'); return; }
    const recent = await store.listRecent(10);
    if (!recent.length) { console.log('No episodes yet.'); return; }
    console.log('Recent episodes:');
    for (const e of recent) console.log(`  ${e.episode_id}  [${e.status}]  ${e.created_at.slice(0, 16)}`);
    console.log('\nFull report: npm run report <episodeId>');
    return;
  }
  console.log(formatEpisodeReport(await buildEpisodeReport(store, id)));
}
main().catch((e) => { console.error(String(e?.message ?? e)); process.exit(1); });
