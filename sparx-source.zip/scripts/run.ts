// Produce one episode end to end. Usage: npm run episode -- "optional niche"
import 'dotenv/config';
import { config } from '../src/config.js';
import { log } from '../src/logger.js';
import { preflightReport, formatPreflight } from '../src/preflight.js';
import { produceEpisode } from '../src/runEpisode.js';
import { renderReview } from '../src/producer/review.js';
import { buildCostReport, formatCostReport } from '../src/cost/report.js';
import { getLLM } from '../src/llm/client.js';

async function main() {
  const c = config();
  const niche = process.argv.slice(2).join(' ').trim() || c.CHANNEL_NICHE;
  console.log(formatPreflight(preflightReport()) + '\n');

  log.info('starting episode', { niche, autoApproveGates: c.AUTO_APPROVE_GATES });
  const final = await produceEpisode(niche);

  console.log('\n──────────── episode result ────────────');
  console.log(`episode:  ${final.episode_id}`);
  console.log(`status:   ${final.status}`);
  console.log(formatCostReport(buildCostReport(final)));
  console.log(`llm spend: $${getLLM().totalUsage().costUsd.toFixed(4)}`);

  if (final.status === 'on_hold') {
    const last = final.history[final.history.length - 1];
    console.log(`\n⚠ on hold: ${last?.event ?? 'budget or guard stop'}`);
    return;
  }
  if (final.review) {
    console.log('\n' + renderReview(final.review));
    console.log(`\n▌ Paused for review:`);
    console.log(`    npm run review approve ${final.episode_id}`);
    console.log(`    npm run review revise  ${final.episode_id} "what to change"`);
    console.log(`    npm run review reject  ${final.episode_id}`);
    return;
  }
  if (final.status === 'published') {
    console.log(`render:   ${final.edit.render_uri}`);
    console.log(`title:    ${final.packaging.titles[0] ?? '(none)'}`);
    console.log(`video id: ${final.publish.youtube_video_id || '(none)'}  · shorts: ${final.shorts.length} · thumbs: ${final.packaging.thumbnails.length}`);
  }
}
main().catch((e) => { log.error('episode failed', { error: String(e?.stack ?? e) }); process.exit(1); });
