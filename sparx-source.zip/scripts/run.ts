// Produce one episode end to end. Usage: npm run episode -- "optional niche"
import 'dotenv/config';
import { config } from '../src/config.js';
import { log } from '../src/logger.js';
import { preflightReport, formatPreflight } from '../src/preflight.js';
import { newEpisodeState, type HostMode } from '../src/types/episode.js';
import { Producer } from '../src/producer/producer.js';
import { renderReview } from '../src/producer/review.js';
import { getLLM } from '../src/llm/client.js';

async function main() {
  const c = config();
  const niche = process.argv.slice(2).join(' ').trim() || c.CHANNEL_NICHE;

  console.log(formatPreflight(preflightReport()) + '\n');

  const episodeId = `ep_${new Date().toISOString().slice(0, 16).replace(/[-:T]/g, '_')}`;
  const state = newEpisodeState(episodeId, {
    niche,
    languages: ['en'],
    host_mode: (process.env.HOST_MODE as HostMode) || 'mixed',
    cap_usd_month: c.BUDGET_CAP_USD,
  });

  log.info('starting episode', { episodeId, niche, autoApproveGates: c.AUTO_APPROVE_GATES });
  const producer = new Producer();
  const final = await producer.run(state);

  console.log('\n──────────── episode result ────────────');
  console.log(`episode:   ${final.episode_id}`);
  console.log(`status:    ${final.status}`);
  console.log(`spend:     $${final.budget.spent_this_episode_usd.toFixed(2)} / $${final.budget.cap_usd_month}  (llm $${getLLM().totalUsage().costUsd.toFixed(4)})`);

  if (final.review) {
    console.log('\n' + renderReview(final.review));
    console.log(`\n▌ Paused for review. Decide with:`);
    console.log(`    npm run review approve ${final.episode_id}`);
    console.log(`    npm run review revise  ${final.episode_id} "what to change"`);
    console.log(`    npm run review reject  ${final.episode_id}`);
    return;
  }

  if (final.status === 'published') {
    console.log(`render:    ${final.edit.render_uri}`);
    console.log(`title:     ${final.publish.youtube_video_id ? final.packaging.titles[0] : '(none)'}`);
    console.log(`video id:  ${final.publish.youtube_video_id || '(none)'}`);
    console.log(`shorts:    ${final.shorts.length}`);
    console.log(`thumbs:    ${final.packaging.thumbnails.length}`);
  } else {
    console.log(`(ended at ${final.status})`);
  }
}
main().catch((e) => { log.error('episode failed', { error: String(e?.stack ?? e) }); process.exit(1); });
