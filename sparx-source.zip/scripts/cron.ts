// Weekly automated episode kickoff. Run: npm run schedule  (keeps running)
// Schedule via CRON_SCHEDULE in .env (default: Monday 09:00). For serverless,
// use the GitHub Action in .github/workflows/weekly-episode.yml instead.
import 'dotenv/config';
import cron from 'node-cron';
import { config } from '../src/config.js';
import { produceEpisode } from '../src/runEpisode.js';
import { buildCostReport, formatCostReport } from '../src/cost/report.js';
import { log } from '../src/logger.js';

const schedule = config().CRON_SCHEDULE;
if (!cron.validate(schedule)) { console.error(`Invalid CRON_SCHEDULE: ${schedule}`); process.exit(1); }

log.info('scheduler started', { schedule, niche: config().CHANNEL_NICHE });
cron.schedule(schedule, async () => {
  log.info('cron: producing episode');
  try {
    const final = await produceEpisode();
    log.info('cron: episode done', { episode: final.episode_id, status: final.status });
    console.log(formatCostReport(buildCostReport(final)));
  } catch (e) {
    log.error('cron: episode failed', { error: String((e as Error)?.stack ?? e) });
  }
});
console.log(`Scheduler running (${schedule}). Ctrl+C to stop.`);
