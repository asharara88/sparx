// Per-episode cost report. Usage: npm run cost <episodeId>   (needs Supabase to load)
import 'dotenv/config';
import { createStore } from '../src/state/store.js';
import { buildCostReport, formatCostReport } from '../src/cost/report.js';

const id = process.argv[2];
if (!id) { console.log('Usage: npm run cost <episodeId>'); process.exit(0); }
const s = await createStore().load(id);
if (!s) { console.log('Episode not found (Supabase required to load past episodes).'); process.exit(0); }
console.log(formatCostReport(buildCostReport(s)));
