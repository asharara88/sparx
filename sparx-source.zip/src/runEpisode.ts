import { config } from './config.js';
import { newEpisodeState, type HostMode, type EpisodeState } from './types/episode.js';
import { Producer } from './producer/producer.js';

// Single entrypoint for producing an episode — shared by the CLI and the scheduler.
export async function produceEpisode(niche?: string): Promise<EpisodeState> {
  const c = config();
  const episodeId = `ep_${new Date().toISOString().slice(0, 16).replace(/[-:T]/g, '_')}`;
  const state = newEpisodeState(episodeId, {
    niche: niche || c.CHANNEL_NICHE,
    languages: [c.EPISODE_LANGUAGE],
    dialect: c.EPISODE_DIALECT,
    host_mode: (process.env.HOST_MODE as HostMode) || 'mixed',
    cap_usd_month: c.BUDGET_CAP_USD,
  });
  return new Producer().run(state);
}
