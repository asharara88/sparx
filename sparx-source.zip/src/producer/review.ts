import type { EpisodeState, ReviewRequest, ReviewItem } from '../types/episode.js';

// Builds a concise, human-readable review payload for each gate so a person can
// approve / revise / reject without digging through the raw state.
export function buildReviewPayload(gate: 'A' | 'B' | 'C', state: EpisodeState): ReviewRequest {
  const now = new Date().toISOString();
  if (gate === 'A') {
    const c = state.concept;
    const items: ReviewItem[] = [
      { label: 'Working title', value: c.working_title },
      { label: 'Angle', value: c.angle },
      { label: 'Audience', value: c.audience },
      { label: 'Thumbnail idea', value: c.thumbnail_concept },
      { label: 'Keywords', value: c.keywords.slice(0, 8).join(', ') },
      { label: 'Other angles considered', value: c.angle_candidates.map((a) => `(${a.score}) ${a.angle}`).join(' | ') || '—' },
      { label: 'Target length', value: `${c.target_length_min} min` },
    ];
    return { gate, state: 'concept_review', title: 'Concept approval', summary: `Approve the angle for "${c.topic}".`, items, requested_at: now };
  }
  if (gate === 'B') {
    const sc = state.script;
    const est = state.shot_list.reduce((n, s) => n + s.cost_estimate_usd, 0);
    const gen = state.shot_list.filter((s) => s.source === 'generated').length;
    const items: ReviewItem[] = [
      { label: 'Hook', value: sc.hook },
      { label: 'Sections', value: `${sc.sections.length} (${sc.word_count} words)` },
      { label: 'Beat sheet', value: sc.beat_sheet.join(' → ') },
      { label: 'Self-critique', value: sc.critique },
      { label: 'CTA', value: sc.cta },
      { label: 'Shots', value: `${state.shot_list.length} (${gen} AI-generated)` },
      { label: 'Est. generation cost', value: `$${est.toFixed(2)}` },
    ];
    return { gate, state: 'script_review', title: 'Script + shot-list approval', summary: 'Approve the script and shot plan before any paid generation.', items, requested_at: now };
  }
  // gate C
  const items: ReviewItem[] = [
    { label: 'Render', value: state.edit.render_uri.startsWith('/') ? `rendered (${state.edit.render_uri})` : 'placeholder (mock assets)' },
    { label: 'Duration', value: `${state.edit.duration_s}s` },
    { label: 'Captioned', value: String(state.edit.captioned) },
    { label: 'QA', value: state.qa.passed ? 'passed' : `HELD: ${state.qa.blocking_issues.join('; ')}` },
    { label: 'AI disclosure', value: String(state.qa.ai_disclosure_required) },
    { label: 'Top title', value: state.packaging.titles[0] ?? '—' },
    { label: 'Thumbnails', value: String(state.packaging.thumbnails.length) },
  ];
  return { gate: 'C', state: 'cut_review', title: 'Final-cut approval', summary: 'Approve the final cut before publishing.', items, requested_at: now };
}

export function renderReview(r: ReviewRequest): string {
  const lines = [`GATE ${r.gate} — ${r.title}`, r.summary, ''];
  for (const it of r.items) lines.push(`  • ${it.label}: ${it.value}`);
  return lines.join('\n');
}
