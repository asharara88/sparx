import { existsSync } from 'node:fs';
import ffmpegPath from 'ffmpeg-static';

// Readiness check: which integrations are LIVE (key present) vs MOCK, plus tooling.
// Reads from an env object (defaults to process.env) so it is easy to test.
// Never prints secret values — only presence/absence.
export interface Check { name: string; ok: boolean; mode: 'live' | 'mock' | 'n/a'; note: string }

export function preflightReport(env: NodeJS.ProcessEnv = process.env): Check[] {
  const has = (k: string) => !!(env[k] && env[k]!.trim());
  const checks: Check[] = [];

  checks.push({ name: 'LLM (Anthropic)', ok: true, mode: has('ANTHROPIC_API_KEY') ? 'live' : 'mock', note: has('ANTHROPIC_API_KEY') ? (env.LLM_MODEL || 'claude-sonnet-4-6') : 'mock outputs (set ANTHROPIC_API_KEY)' });
  checks.push({ name: 'Web research (Tavily)', ok: true, mode: has('TAVILY_API_KEY') ? 'live' : 'mock', note: has('TAVILY_API_KEY') ? 'live search' : 'mock results' });
  checks.push({ name: 'Voiceover (ElevenLabs)', ok: true, mode: has('ELEVENLABS_API_KEY') ? 'live' : 'mock', note: has('ELEVENLABS_API_KEY') ? 'live TTS' : 'mock audio' });
  checks.push({ name: 'Video + thumbnails (Runway)', ok: true, mode: has('RUNWAY_API_KEY') ? 'live' : 'mock', note: has('RUNWAY_API_KEY') ? (env.RUNWAY_MODEL || 'gen4.5') : 'mock clips' });
  const heygenLive = has('HEYGEN_API_KEY');
  const heygenIds = has('HEYGEN_AVATAR_ID') && has('HEYGEN_VOICE_ID');
  checks.push({ name: 'Avatar (HeyGen)', ok: !heygenLive || heygenIds, mode: heygenLive ? 'live' : 'mock', note: heygenLive ? (heygenIds ? 'key + avatar/voice IDs set' : 'KEY set but missing HEYGEN_AVATAR_ID/VOICE_ID') : 'mock avatar' });
  checks.push({ name: 'Stock (Pexels)', ok: true, mode: has('PEXELS_API_KEY') ? 'live' : 'mock', note: has('PEXELS_API_KEY') ? 'live stock' : 'mock stock' });
  checks.push({ name: 'Publish (YouTube)', ok: true, mode: has('YOUTUBE_ACCESS_TOKEN') ? 'live' : 'mock', note: has('YOUTUBE_ACCESS_TOKEN') ? `upload as "${env.YOUTUBE_PRIVACY || 'private'}"` : 'metadata only (no upload)' });

  const sb = has('SUPABASE_URL') && (has('SUPABASE_SERVICE_ROLE_KEY') || has('SUPABASE_PUBLISHABLE_KEY'));
  checks.push({ name: 'Persistence (Supabase)', ok: true, mode: sb ? 'live' : 'mock', note: sb ? 'episodes persisted' : 'in-memory (set SUPABASE_* to persist)' });

  const ff = (ffmpegPath as unknown as string) || '';
  const ffOk = !!ff && existsSync(ff);
  checks.push({ name: 'Render (ffmpeg)', ok: ffOk, mode: ffOk ? 'live' : 'n/a', note: ffOk ? 'ffmpeg-static available' : 'ffmpeg missing (run npm install)' });

  return checks;
}

export function formatPreflight(checks: Check[]): string {
  const rows = checks.map((c) => {
    const icon = !c.ok ? '✗' : c.mode === 'live' ? '●' : c.mode === 'mock' ? '○' : '–';
    return `  ${icon} ${c.name.padEnd(28)} ${c.mode.toUpperCase().padEnd(5)} ${c.note}`;
  });
  const live = checks.filter((c) => c.mode === 'live').length;
  const problems = checks.filter((c) => !c.ok).length;
  return [`Preflight — ${live}/${checks.length} integrations live${problems ? `, ${problems} problem(s)` : ''}:`, ...rows,
    '  ● live   ○ mock   ✗ misconfigured'].join('\n');
}

export function hasBlockingProblems(checks: Check[]): boolean { return checks.some((c) => !c.ok); }
