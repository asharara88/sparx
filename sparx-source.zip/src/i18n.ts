// Language handling for multi-language episodes. Viewer-facing text (titles,
// narration, on-screen text, captions, descriptions) is written in the target
// language; image/video generation prompts stay in English (models perform best
// in English). Returns '' for English so existing behavior is unchanged.
const LANG_NAMES: Record<string, string> = {
  ar: 'Arabic', es: 'Spanish', fr: 'French', de: 'German', pt: 'Portuguese',
  it: 'Italian', hi: 'Hindi', ur: 'Urdu', tr: 'Turkish', ja: 'Japanese',
  ko: 'Korean', zh: 'Chinese', ru: 'Russian', id: 'Indonesian', nl: 'Dutch',
};

export function languageName(lang: string): string {
  const k = (lang || 'en').toLowerCase().split('-')[0]!;
  return LANG_NAMES[k] ?? k;
}

export function isEnglish(languages: string[]): boolean {
  const k = (languages[0] || 'en').toLowerCase().split('-')[0];
  return k === 'en';
}

// Prompt directive to prepend to viewer-facing LLM calls.
export function languageDirective(languages: string[], dialect?: string): string {
  if (isEnglish(languages)) return '';
  const name = languageName(languages[0] || 'en');
  const d = dialect ? ` (${dialect} dialect)` : '';
  return `LANGUAGE: Write ALL viewer-facing text — titles, hooks, narration (vo_text), on-screen text, descriptions, captions — in ${name}${d}. Keep image/video generation prompts and shot descriptions in English. `;
}
