import type { EpisodeState } from '../types/episode.js';
import { getSupabase } from './supabase.js';

// Persistence for the Episode State. Uses Supabase when configured;
// otherwise an in-memory map so the pipeline is runnable in dev/CI.
export interface StateStore {
  save(state: EpisodeState): Promise<void>;
  load(episodeId: string): Promise<EpisodeState | null>;
  logEvent(episodeId: string, agent: string | null, event: string, detail?: unknown): Promise<void>;
  recordCost(episodeId: string, agent: string, costUsd: number, note?: string): Promise<void>;
  listByStatus(statuses: string[]): Promise<{ episode_id: string; status: string }[]>;
  listRecent(limit: number): Promise<{ episode_id: string; status: string; created_at: string }[]>;
  getEvents(episodeId: string): Promise<{ agent: string | null; event: string; at: string }[]>;
  getLedger(episodeId: string): Promise<{ agent: string; cost_usd: number; at: string }[]>;
}

class MemoryStore implements StateStore {
  private map = new Map<string, EpisodeState>();
  async save(s: EpisodeState) { this.map.set(s.episode_id, structuredClone(s)); }
  async load(id: string) { const s = this.map.get(id); return s ? structuredClone(s) : null; }
  async logEvent() { /* no-op in memory */ }
  async recordCost() { /* tracked inside state.budget.ledger */ }
  async listByStatus(statuses: string[]) {
    return [...this.map.values()].filter((s) => statuses.includes(s.status)).map((s) => ({ episode_id: s.episode_id, status: s.status }));
  }
  async listRecent(limit: number) {
    return [...this.map.values()].sort((a, b) => b.created_at.localeCompare(a.created_at)).slice(0, limit).map((s) => ({ episode_id: s.episode_id, status: s.status, created_at: s.created_at }));
  }
  async getEvents(episodeId: string) {
    const s = this.map.get(episodeId); return s ? s.history.map((h) => ({ agent: h.agent, event: h.event, at: h.at })) : [];
  }
  async getLedger(episodeId: string) {
    const s = this.map.get(episodeId); return s ? s.budget.ledger.map((l) => ({ agent: l.agent, cost_usd: l.cost_usd, at: l.at })) : [];
  }
}

class SupabaseStore implements StateStore {
  constructor(private client = getSupabase()!) {}
  async save(s: EpisodeState) {
    const { error } = await this.client.from('episodes').upsert({
      episode_id: s.episode_id,
      status: s.status,
      niche: s.channel.niche || null,
      host_mode: s.channel.host_mode,
      state: s,
      spent_usd: s.budget.spent_this_episode_usd,
    });
    if (error) throw new Error(`Supabase save failed: ${error.message}`);
  }
  async load(id: string) {
    const { data, error } = await this.client.from('episodes').select('state').eq('episode_id', id).maybeSingle();
    if (error) throw new Error(`Supabase load failed: ${error.message}`);
    return (data?.state as EpisodeState) ?? null;
  }
  async logEvent(episodeId: string, agent: string | null, event: string, detail?: unknown) {
    await this.client.from('pipeline_events').insert({ episode_id: episodeId, agent, event, detail: detail ?? null });
  }
  async recordCost(episodeId: string, agent: string, costUsd: number, note?: string) {
    await this.client.from('budget_ledger').insert({ episode_id: episodeId, agent, cost_usd: costUsd, note: note ?? null });
  }
  async listByStatus(statuses: string[]) {
    const { data, error } = await this.client.from('episodes').select('episode_id,status').in('status', statuses);
    if (error) throw new Error(`Supabase listByStatus failed: ${error.message}`);
    return (data ?? []) as { episode_id: string; status: string }[];
  }
  async listRecent(limit: number) {
    const { data, error } = await this.client.from('episodes').select('episode_id,status,created_at').order('created_at', { ascending: false }).limit(limit);
    if (error) throw new Error(`Supabase listRecent failed: ${error.message}`);
    return (data ?? []) as { episode_id: string; status: string; created_at: string }[];
  }
  async getEvents(episodeId: string) {
    const { data, error } = await this.client.from('pipeline_events').select('agent,event,created_at').eq('episode_id', episodeId).order('created_at', { ascending: true });
    if (error) throw new Error(`Supabase getEvents failed: ${error.message}`);
    return (data ?? []).map((r: any) => ({ agent: r.agent, event: r.event, at: r.created_at }));
  }
  async getLedger(episodeId: string) {
    const { data, error } = await this.client.from('budget_ledger').select('agent,cost_usd,created_at').eq('episode_id', episodeId).order('created_at', { ascending: true });
    if (error) throw new Error(`Supabase getLedger failed: ${error.message}`);
    return (data ?? []).map((r: any) => ({ agent: r.agent, cost_usd: Number(r.cost_usd), at: r.created_at }));
  }
}

export function createStore(): StateStore {
  return getSupabase() ? new SupabaseStore() : new MemoryStore();
}
