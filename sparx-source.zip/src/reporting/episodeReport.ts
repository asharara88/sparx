import type { StateStore } from '../state/store.js';
import { buildCostReport, formatCostReport, type CostReport } from '../cost/report.js';
import type { EpisodeState } from '../types/episode.js';

export interface EpisodeReport {
  found: boolean;
  state?: EpisodeState;
  events: { agent: string | null; event: string; at: string }[];
  cost?: CostReport;
}

export async function buildEpisodeReport(store: StateStore, episodeId: string): Promise<EpisodeReport> {
  const state = await store.load(episodeId);
  if (!state) return { found: false, events: [] };
  const events = await store.getEvents(episodeId);
  return { found: true, state, events, cost: buildCostReport(state) };
}

export function formatEpisodeReport(r: EpisodeReport): string {
  if (!r.found || !r.state) return 'Episode not found.';
  const s = r.state;
  const L: string[] = [];
  L.push(`════ Episode ${s.episode_id} ════`);
  L.push(`status:   ${s.status}    niche: ${s.channel.niche}    host: ${s.channel.host_mode}`);
  L.push(`created:  ${s.created_at}`);
  L.push('');
  L.push(`concept:  ${s.concept.working_title || '(none)'}`);
  L.push(`          ${s.concept.angle}`);
  L.push(`script:   ${s.script.sections.length} sections, ${s.script.word_count} words`);
  L.push(`media:    ${s.generated_video.length} gen clips · ${s.avatar_clips.length} avatar · ${s.sourced_assets.length} stock`);
  L.push(`render:   ${s.edit.render_uri || '(none)'}  (${s.edit.duration_s}s)`);
  L.push(`qa:       ${s.qa.passed ? 'passed' : 'HELD: ' + s.qa.blocking_issues.join('; ')}  · AI-disclosure: ${s.qa.ai_disclosure_required}`);
  L.push(`publish:  ${s.publish.youtube_video_id || '(none)'}  · ${s.shorts.length} shorts · ${s.packaging.thumbnails.length} thumbs · ${s.publish.chapters.length} chapters`);
  L.push('');
  if (r.cost) L.push(formatCostReport(r.cost));
  L.push('');
  L.push(`timeline (${r.events.length} events):`);
  for (const e of r.events) L.push(`  ${e.at.slice(11, 19)}  ${(e.agent ?? '—').padEnd(16)} ${e.event}`);
  return L.join('\n');
}
