import type { EpisodeState } from '../types/episode.js';

// Per-episode cost breakdown built from the budget ledger.
export interface CostReport {
  episode_id: string;
  total_usd: number;
  cap_usd: number;
  remaining_usd: number;
  over_budget: boolean;
  by_agent: { agent: string; usd: number }[];
}

export function buildCostReport(state: EpisodeState): CostReport {
  const byAgent = new Map<string, number>();
  for (const e of state.budget.ledger) byAgent.set(e.agent, (byAgent.get(e.agent) ?? 0) + e.cost_usd);
  const total = Math.round(state.budget.spent_this_episode_usd * 1e4) / 1e4;
  const cap = state.budget.cap_usd_month;
  return {
    episode_id: state.episode_id,
    total_usd: total,
    cap_usd: cap,
    remaining_usd: Math.round((cap - total) * 1e4) / 1e4,
    over_budget: total > cap,
    by_agent: [...byAgent.entries()].map(([agent, usd]) => ({ agent, usd: Math.round(usd * 1e4) / 1e4 })).sort((a, b) => b.usd - a.usd),
  };
}

export function formatCostReport(r: CostReport): string {
  const lines = [`Cost — episode ${r.episode_id}: $${r.total_usd.toFixed(4)} / $${r.cap_usd} cap (remaining $${r.remaining_usd.toFixed(2)})${r.over_budget ? '  ⚠ OVER BUDGET' : ''}`];
  for (const a of r.by_agent) if (a.usd > 0) lines.push(`  ${a.agent.padEnd(20)} $${a.usd.toFixed(4)}`);
  if (r.by_agent.every((a) => a.usd === 0)) lines.push('  (no paid spend — mock providers)');
  return lines.join('\n');
}
